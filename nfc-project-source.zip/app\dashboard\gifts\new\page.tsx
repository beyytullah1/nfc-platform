import { GiftForm } from "../GiftForm"

export default function NewGiftPage() {
    return <GiftForm />
}
